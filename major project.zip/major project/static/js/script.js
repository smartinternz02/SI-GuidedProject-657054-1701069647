function validateForm() {
    var ageInput = document.getElementById("age").value;
    if (ageInput < 18 || ageInput > 100) {
        alert("Age must be between 18 and 100.");
        return false;
    }
    return true;
}
